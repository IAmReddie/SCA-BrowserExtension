// Keeps the background service worker alive by maintaining an open port.
// Chrome will not terminate a service worker that has active port connections.
function keepAlive() {
  const port = chrome.runtime.connect({ name: "keepAlive" });
  port.onDisconnect.addListener(() => {
    setTimeout(keepAlive, 1000);
  });
}

keepAlive();
