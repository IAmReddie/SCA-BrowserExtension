const dot = document.getElementById("dot");
const statusText = document.getElementById("statusText");
const wsInput = document.getElementById("wsInput");
const saveBtn = document.getElementById("saveBtn");
const reconnectBtn = document.getElementById("reconnectBtn");
const tokenValue = document.getElementById("tokenValue");
const copyBtn = document.getElementById("copyBtn");

function renderStatus(status) {
  dot.className = "dot " + status;
  const labels = {
    connected: "Connected to bridge",
    connecting: "Connecting...",
    disconnected: "Disconnected",
    error: "Connection error",
  };
  statusText.textContent = labels[status] || status;
}

function loadState() {
  chrome.runtime.sendMessage({ type: "getStatus" }, (res) => {
    if (!res) return;
    renderStatus(res.status || "disconnected");
    wsInput.value = res.wsUrl || "wss://sound-cloud-discord-bot.replit.app/api/ws";
    tokenValue.textContent = res.token || "—";
  });
}

copyBtn.addEventListener("click", () => {
  const token = tokenValue.textContent;
  if (!token || token === "—") return;
  navigator.clipboard.writeText(token).then(() => {
    copyBtn.textContent = "Copied!";
    copyBtn.classList.add("copied");
    setTimeout(() => {
      copyBtn.textContent = "Copy";
      copyBtn.classList.remove("copied");
    }, 1500);
  });
});

saveBtn.addEventListener("click", () => {
  const url = wsInput.value.trim() || "ws://localhost:80/api/ws";
  chrome.storage.local.set({ wsUrl: url }, () => {
    chrome.runtime.sendMessage({ type: "reconnect" }, () => {
      setTimeout(loadState, 500);
    });
  });
});

reconnectBtn.addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "reconnect" }, () => {
    setTimeout(loadState, 500);
  });
});

loadState();
setInterval(loadState, 2000);
