const DEFAULT_WS_URL = "wss://sound-cloud-discord-bot.replit.app/api/ws";

let ws = null;
let reconnectTimer = null;
let wsUrl = DEFAULT_WS_URL;
let myToken = null;
let status = "disconnected";

function setStatus(s) {
  status = s;
  chrome.storage.local.set({ status: s });
}

function generateToken() {
  const arr = new Uint8Array(16);
  crypto.getRandomValues(arr);
  return Array.from(arr).map(b => b.toString(16).padStart(2, "0")).join("");
}

async function loadSettings() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["wsUrl", "token"], (result) => {
      wsUrl = result.wsUrl || DEFAULT_WS_URL;
      if (!result.token) {
        myToken = generateToken();
        chrome.storage.local.set({ token: myToken });
      } else {
        myToken = result.token;
      }
      resolve();
    });
  });
}

function identify() {
  if (ws && ws.readyState === WebSocket.OPEN && myToken) {
    ws.send(JSON.stringify({ type: "identify", token: myToken }));
  }
}

function connect() {
  if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) return;

  setStatus("connecting");

  ws = new WebSocket(wsUrl);

  ws.onopen = () => {
    setStatus("connected");
    if (reconnectTimer) {
      clearTimeout(reconnectTimer);
      reconnectTimer = null;
    }
    identify();
  };

  ws.onmessage = async (event) => {
    let payload;
    try {
      payload = JSON.parse(event.data);
    } catch {
      return;
    }

    if (payload.type === "connected" || payload.type === "identified") return;

    const tabs = await chrome.tabs.query({ url: "https://soundcloud.com/*" });
    if (tabs.length === 0) {
      ws.send(JSON.stringify({ type: "error", message: "No SoundCloud tab found" }));
      return;
    }

    for (const tab of tabs) {
      try {
        const results = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: executeCommand,
          args: [payload],
        });

        const trackInfo = results[0]?.result;
        if (trackInfo && payload.requestId) {
          ws.send(JSON.stringify({
            type: "track_info",
            requestId: payload.requestId,
            title: trackInfo.title,
            artist: trackInfo.artist,
            artworkUrl: trackInfo.artworkUrl ?? null,
          }));
        }
        break;
      } catch (err) {
        console.error("Failed to execute script in tab", tab.id, err);
      }
    }
  };

  ws.onclose = () => {
    setStatus("disconnected");
    reconnectTimer = setTimeout(connect, 3000);
  };

  ws.onerror = () => {
    setStatus("error");
    ws.close();
  };
}

// This function is injected into the SoundCloud page — keep it self-contained.
async function executeCommand(payload) {
  function click(selector) {
    const el = document.querySelector(selector);
    if (el) el.click();
    return !!el;
  }

  function getCurrentTrack() {
    // Title — read aria-label to skip the hidden "Current track: " prefix span
    const titleEl = document.querySelector(".playbackSoundBadge__titleLink span[aria-label]");
    let title = "Unknown";
    if (titleEl) {
      const raw = titleEl.getAttribute("aria-label") || "";
      title = raw.replace(/^Current track:\s*/i, "").trim() || titleEl.innerText.trim() || "Unknown";
    } else {
      // Fallback: grab the visible link text directly
      const fallback = document.querySelector(".playbackSoundBadge__titleLink a, .playbackSoundBadge__title a");
      if (fallback) title = fallback.innerText.trim() || fallback.textContent.trim() || "Unknown";
    }

    // Artist — try every common selector SoundCloud uses
    let artist = "Unknown";
    const artistCandidates = [
      ".playbackSoundBadge__lightLink",
      ".playbackSoundBadge__avatar a",
      ".playbackSoundBadge__user a",
    ];
    for (const sel of artistCandidates) {
      const el = document.querySelector(sel);
      if (!el) continue;
      const val = el.getAttribute("title")
        || el.getAttribute("aria-label")
        || el.innerText.trim()
        || el.textContent.trim();
      if (val) { artist = val; break; }
    }

    // Artwork
    const artworkEl = document.querySelector(
      ".playbackSoundBadge__artwork .image__full, .playbackSoundBadge .sc-artwork span[style]"
    );
    let artworkUrl = null;
    if (artworkEl) {
      const style = artworkEl.getAttribute("style") || "";
      const match = style.match(/url\(["']?([^"')]+)["']?\)/);
      if (match) artworkUrl = match[1].replace(/-t\d+x\d+\./, "-t500x500.");
    }

    console.log("[SCA] getCurrentTrack:", { title, artist, artworkUrl });
    return { title, artist, artworkUrl };
  }

  const cmd = payload.command;

  if (cmd === "play") {
    click(".playControls__play, button[title='Play']");
  } else if (cmd === "pause") {
    click(".playControls__play, button[title='Pause']");
  } else if (cmd === "skip") {
    click(".skipControl__next, button[title='Next']");
    await new Promise(r => setTimeout(r, 900));
    return getCurrentTrack();
  } else if (cmd === "prev") {
    click(".skipControl__previous, button[title='Previous']");
    await new Promise(r => setTimeout(r, 900));
    return getCurrentTrack();
  } else if (cmd === "like") {
    const btn = document.querySelector(".playbackSoundBadge__like, button[title='Like']");
    if (btn && !btn.classList.contains("sc-button-selected")) btn.click();
  } else if (cmd === "unlike") {
    const btn = document.querySelector(".playbackSoundBadge__like, button[title='Like']");
    if (btn && btn.classList.contains("sc-button-selected")) btn.click();
  } else if (cmd === "mute") {
    const btn = document.querySelector(".volume__button, button[title='Mute']");
    if (btn) btn.click();
  } else if (cmd === "unmute") {
    const btn = document.querySelector(".volume__button, button[title='Unmute']");
    if (btn) btn.click();
  } else if (cmd === "volume") {
    const slider = document.querySelector(".volume__sliderWrapper input[type=range], .volume__slider");
    if (slider) {
      const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set;
      nativeInputValueSetter.call(slider, payload.volume);
      slider.dispatchEvent(new Event("input", { bubbles: true }));
      slider.dispatchEvent(new Event("change", { bubbles: true }));
    }
  } else if (cmd === "status") {
    return getCurrentTrack();
  }
}

chrome.storage.onChanged.addListener((changes) => {
  if (changes.wsUrl) {
    wsUrl = changes.wsUrl.newValue || DEFAULT_WS_URL;
    if (ws) ws.close();
  }
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === "getStatus") {
    sendResponse({ status, wsUrl, token: myToken });
  } else if (msg.type === "reconnect") {
    if (ws) ws.close();
    connect();
    sendResponse({ ok: true });
  }
  return true;
});

// Absorb keepAlive ports from content.js — having an open port prevents
// Chrome from terminating the service worker while SoundCloud is open.
chrome.runtime.onConnect.addListener((port) => {
  if (port.name === "keepAlive") {
    port.onDisconnect.addListener(() => {});
  }
});

// Alarm fires every 25 s as a backup keepAlive (e.g. when SoundCloud isn't open).
// It also reconnects the WebSocket if it was dropped while the worker was sleeping.
chrome.alarms.create("keepAlive", { periodInMinutes: 0.4 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "keepAlive") {
    if (!ws || ws.readyState === WebSocket.CLOSED || ws.readyState === WebSocket.CLOSING) {
      connect();
    }
  }
});

loadSettings().then(() => connect());
